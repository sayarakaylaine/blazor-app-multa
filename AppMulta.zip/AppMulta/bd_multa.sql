create database bd_multa;

CREATE TABLE veiculo (
    id INT,
    modelo VARCHAR(60),
    marca VARCHAR(60),
    placa VARCHAR(60)
);

CREATE TABLE multa (
    id INT,
    descricao VARCHAR(100),
    valor_multa DECIMAL,
    id_veiculo INTEGER
);
 
